package jun.member.dto;

public class MemberDTO {

	int uniqueId;
	String userid;
	String password;
	String nickname;
	String phonenum;
	String email;
	String birthday;
	
	
	public int getUniqueId() {
		return uniqueId;
	}
	public void setUniqueId(int uniqueId) {
		this.uniqueId = uniqueId;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	@Override
	public String toString() {
		return "MemberDTO [uniqueId=" + uniqueId + ", userid=" + userid + ", password=" + password + ", nickname="
				+ nickname + ", phonenum=" + phonenum + ", email=" + email + ", birthday=" + birthday + "]";
	}
	
	
	
}
